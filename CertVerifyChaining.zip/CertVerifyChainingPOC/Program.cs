﻿using System;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace CertVerifyChainingPOC
{
    public class Program
    {
        static void Main(string[] args)
        {
            Logs.PrintInfo($"Welcome {Environment.UserName}");
            Logs.PrintInfo("Start process");
            VerifyInValidCertificate();
            VerifyInValidCertificate();
        }
        
        private static bool VerifyValidCertificate()
        {
            var chain = new X509Chain();
            chain.ChainPolicy.VerificationFlags = X509VerificationFlags.AllowUnknownCertificateAuthority;
            chain.ChainPolicy.ExtraStore.Add(new X509Certificate2("ati-rootcertificate.crt"));

            // You can alter how the chain is built/validated.
            chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
            chain.ChainPolicy.RevocationFlag = X509RevocationFlag.ExcludeRoot;

            // Do the preliminary validation.
            var primaryCert = new X509Certificate2("aristocrat-certificate.pfx");
            
            if (!chain.Build(primaryCert))
                return false;

            // Make sure we have the same number of elements.
            if (chain.ChainElements.Count != chain.ChainPolicy.ExtraStore.Count + 1)
                return false;

            if (chain.ChainStatus.Length != 1 ||chain.ChainStatus.First().Status != X509ChainStatusFlags.UntrustedRoot)
            {
                return false;
            }
            
            // Make sure all the thumbprints of the CAs match up.
            // The first one should be 'primaryCert', leading up to the root CA.
            for (var i = 1; i < chain.ChainElements.Count; i++)
            {
                if (chain.ChainElements[i].Certificate.Thumbprint != chain.ChainPolicy.ExtraStore[i - 1].Thumbprint)
                    return false;
            }
            return true;
        }

        private static bool VerifyInValidCertificate()
        {
            var chain = new X509Chain();
            chain.ChainPolicy.VerificationFlags = X509VerificationFlags.AllowUnknownCertificateAuthority;
            chain.ChainPolicy.ExtraStore.Add(new X509Certificate2("ati-rootcertificate.crt"));

            // You can alter how the chain is built/validated.
            chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
            chain.ChainPolicy.RevocationFlag = X509RevocationFlag.ExcludeRoot;

            // Do the preliminary validation.
            var primaryCert = new X509Certificate2("invalidCert.cer");

            if (!chain.Build(primaryCert))
                return false;

            // Make sure we have the same number of elements.
            if (chain.ChainElements.Count != chain.ChainPolicy.ExtraStore.Count + 1)
                return false;

            if (chain.ChainStatus.Length != 1 || chain.ChainStatus.First().Status != X509ChainStatusFlags.UntrustedRoot)
            {
                return false;
            }

            // Make sure all the thumbprints of the CAs match up.
            // The first one should be 'primaryCert', leading up to the root CA.
            for (var i = 1; i < chain.ChainElements.Count; i++)
            {
                if (chain.ChainElements[i].Certificate.Thumbprint != chain.ChainPolicy.ExtraStore[i - 1].Thumbprint)
                    return false;
            }
            return true;
        }

    }

    public static class Logs
    {
        public static void PrintInfo(string s)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(s);
            Console.ResetColor();
        }

        public static void PrintLog(string s)
        {
            Console.ResetColor();
            Console.WriteLine(s);
        }

        public static void PrintError(string s)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(s);
            Console.ResetColor();
        }
    }
}
